MOVEit Front Door Terraform Deployment
=======================================

PACKAGE CONTENTS
----------------
main.tf           - Complete Terraform configuration
variables.tf      - Variable definitions
terraform.tfvars  - Your configuration values
outputs.tf        - Deployment outputs

WHAT THIS DEPLOYS
-----------------
Network Resources (in rg-networking):
- Network Security Group: nsg-moveit
- NSG Rules: ports 990, 989, 443

Deployment Resources (in rg-moveit):
- Resource Group: rg-moveit (if needed)
- Load Balancer: lb-moveit-ftps
- Public IP: pip-moveit-ftps
- Front Door Profile: moveit-frontdoor-profile
- Front Door Endpoint: moveit-endpoint
- WAF Policy: moveitWAFPolicy
- Defender Plans: VMs, Apps, Storage

CONFIGURATION
-------------
Existing Resources (will be used):
- Resource Group: rg-networking
- Virtual Network: vnet-prod
- Subnet: snet-moveit (192.168.0.0/29)
- MOVEit Server: 192.168.0.5

New Resources (will be created):
- Everything listed above

DEPLOYMENT STEPS
----------------
1. Extract files to: C:\Projects\Pyex-AVD-deployment
2. Open PowerShell
3. cd C:\Projects\Pyex-AVD-deployment
4. terraform init
5. terraform plan (review changes)
6. terraform apply (type yes)

AFTER DEPLOYMENT
----------------
Run: terraform output

You will see:
- FTPS endpoint: Public IP and ports (990, 989)
- HTTPS endpoint: Front Door URL (port 443)
- Security configuration
- Cost estimate

ARCHITECTURE
------------
INTERNET
  |
  +-> Load Balancer (Public IP)
  |   Ports: 990, 989 (FTPS)
  |   |
  |   +-> snet-moveit (192.168.0.0/29)
  |       |
  |       +-> MOVEit Server (192.168.0.5)
  |
  +-> Azure Front Door (HTTPS URL)
      Port: 443 (HTTPS)
      WAF: DefaultRuleSet 1.0 + Bot Manager
      |
      +-> snet-moveit (192.168.0.0/29)
          |
          +-> MOVEit Server (192.168.0.5)

COST
----
Load Balancer: $18/month
Front Door: $35/month
WAF: $30/month
Total: $83/month

CLEANUP
-------
To remove all resources:
terraform destroy

Note: This will NOT delete:
- rg-networking
- vnet-prod
- snet-moveit

SUPPORT
-------
All configuration values are in terraform.tfvars
To change anything, edit that file and rerun:
terraform plan
terraform apply
